<?php
declare(strict_types=1);
require_once __DIR__.'/includes/auth.php';
sessao_iniciar();
// Só encerra por POST com token CSRF, para que um link externo não deslogue a equipe.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_SESSION['uid'])) csrf_validar();
    sessao_encerrar();
}
redirecionar('login.php');
