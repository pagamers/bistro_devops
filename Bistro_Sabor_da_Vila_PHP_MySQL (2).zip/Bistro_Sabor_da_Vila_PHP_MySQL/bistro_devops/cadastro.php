<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
sessao_iniciar();
if (usuario_atual($pdo)) redirecionar('index.php');

$erro = '';
$v = ['nome' => '', 'usuario' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    // Campo-isca invisível: humanos não preenchem; robôs sim. Descarta em silêncio.
    if (trim((string)($_POST['site'] ?? '')) !== '') redirecionar('login.php');

    $v['nome'] = trim((string)($_POST['nome'] ?? ''));
    $v['usuario'] = strtolower(trim((string)($_POST['usuario'] ?? '')));
    $senha = (string)($_POST['senha'] ?? '');
    $conf = (string)($_POST['senha_conf'] ?? '');
    try {
        if ($v['nome'] === '' || mb_strlen($v['nome']) > 120) $erro = 'Informe seu nome (até 120 caracteres).';
        elseif (!preg_match('/^[a-z0-9._-]{3,60}$/', $v['usuario'])) $erro = 'Usuário: 3 a 60 caracteres, só minúsculas, números, ponto, hífen e sublinhado.';
        elseif ($senha !== $conf) $erro = 'A confirmação não confere com a senha.';
        elseif (($msg = validar_senha_nova($senha)) !== null) $erro = $msg;
        else {
            $existe = $pdo->prepare('SELECT 1 FROM usuarios WHERE usuario=?'); $existe->execute([$v['usuario']]);
            if ($existe->fetch()) $erro = 'Esse nome de usuário já está em uso.';
            else {
                // Autocadastro: conta de CLIENTE, ativa na hora (sem aprovação). Nunca cria funcionário/admin.
                $pdo->prepare("INSERT INTO usuarios (nome,usuario,senha_hash,perfil) VALUES (?,?,?,'cliente')")
                    ->execute([$v['nome'], $v['usuario'], password_hash($senha, PASSWORD_DEFAULT)]);
                $novoId = (int)$pdo->lastInsertId();
                $pdo->prepare('UPDATE usuarios SET ultimo_login=NOW() WHERE id=?')->execute([$novoId]);
                session_regenerate_id(true);
                $_SESSION['uid'] = $novoId;
                $_SESSION['ultima_atividade'] = time();
                unset($_SESSION['csrf']);
                redirecionar('index.php');
            }
        }
    } catch (Throwable $ex) {
        error_log('Erro no cadastro: '.$ex->getMessage());
        $erro = ($ex instanceof PDOException && $ex->getCode() === '23000')
            ? 'Esse nome de usuário já está em uso.'
            : 'Não foi possível criar a conta agora. Tente novamente.';
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Criar conta | Bistrô Sabor da Vila</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page">
<main class="login-box"><div class="panel">
<a class="brand login-brand" href="login.php"><span class="brand-icon">SV</span><span>Bistrô <b>Sabor da Vila</b><small>PAINEL DE COMANDAS</small></span></a>
<h1 class="login-title">Criar conta</h1><p class="hint">Crie sua conta de <b>cliente</b> e comece a fazer pedidos agora mesmo.</p>
<?php if($erro):?><div class="alert error"><?=e($erro)?></div><?php endif;?>
<form method="post" class="admin-form" autocomplete="off"><?=csrf_campo()?>
<div class="hp" aria-hidden="true"><label>Não preencha<input name="site" tabindex="-1" autocomplete="off"></label></div>
<label>Nome completo<input name="nome" required maxlength="120" value="<?=e($v['nome'])?>" autofocus></label>
<label>Usuário (login)<input name="usuario" required maxlength="60" pattern="[a-z0-9._\-]{3,60}" autocapitalize="none" value="<?=e($v['usuario'])?>" placeholder="ex.: maria.souza"></label>
<label>Senha <span class="muted">(mín. 8 caracteres, com letras e números)</span><input name="senha" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></label>
<label>Confirmar senha<input name="senha_conf" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></label>
<button class="button primary full" type="submit">Criar conta</button></form>
<p class="hint login-link">Já tem conta? <a href="login.php">Entrar</a></p>
</div></main></body></html>
