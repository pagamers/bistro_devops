-- Para bancos que JÁ têm comandas/produtos (database.sql sem login) e NÃO têm a tabela usuarios.
-- Rode UMA vez, no banco selecionado. Não apaga comandas nem produtos.
CREATE TABLE IF NOT EXISTS usuarios (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 nome VARCHAR(120) NOT NULL,
 usuario VARCHAR(60) NOT NULL,
 senha_hash VARCHAR(255) NOT NULL,
 perfil ENUM('cliente','funcionario','admin') NOT NULL DEFAULT 'cliente',
 ativo TINYINT(1) NOT NULL DEFAULT 1,
 trocar_senha TINYINT(1) NOT NULL DEFAULT 0,
 tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
 bloqueado_ate DATETIME DEFAULT NULL,
 ultimo_login DATETIME DEFAULT NULL,
 criado_por INT UNSIGNED DEFAULT NULL,
 criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), UNIQUE KEY uq_usuarios_usuario (usuario),
 CONSTRAINT fk_usuarios_criado_por FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin principal: usuário paisão | senha 12345678
-- Clientes se cadastram sozinhos (cadastro.php); só um admin cria funcionários e admins.
SET NAMES utf8mb4;
INSERT INTO usuarios (nome,usuario,senha_hash,perfil,trocar_senha)
SELECT 'paisão','paisão','$2y$12$TXlVT/feNNETXoQ5LYvHbeiMihzLOkMJB0ZktZK280hC7voq3Kot6','admin',0
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE usuario='paisão');

ALTER TABLE comandas ADD COLUMN usuario_id INT UNSIGNED DEFAULT NULL AFTER numero;
ALTER TABLE comandas ADD INDEX idx_comandas_usuario (usuario_id);
ALTER TABLE comandas ADD CONSTRAINT fk_comandas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
