<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
sessao_iniciar();
if (usuario_atual($pdo)) redirecionar('index.php');

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $login = trim((string)($_POST['usuario'] ?? ''));
    $senha = (string)($_POST['senha'] ?? '');
    $generico = 'Usuário ou senha incorretos.';
    try {
        $s = $pdo->prepare('SELECT id,senha_hash,ativo,tentativas,bloqueado_ate FROM usuarios WHERE usuario=?');
        $s->execute([$login]);
        $u = $s->fetch();
        // Executa sempre um password_verify para não revelar, pelo tempo, se o usuário existe.
        $hashRef = $u['senha_hash'] ?? '$2y$12$hsU5uzpmoBFqxpktI0plF.roZX3Ti8Tveh.UZw29LpPeE0YQUi33.';
        $senhaOk = password_verify($senha, $hashRef);
        $bloqueado = $u && $u['bloqueado_ate'] && strtotime((string)$u['bloqueado_ate']) > time();

        if ($bloqueado) {
            $erro = 'Muitas tentativas. Aguarde alguns minutos e tente de novo.';
        } elseif ($u && (int)$u['ativo'] === 1 && $senhaOk) {
            if (password_needs_rehash($u['senha_hash'], PASSWORD_DEFAULT)) {
                $pdo->prepare('UPDATE usuarios SET senha_hash=? WHERE id=?')->execute([password_hash($senha, PASSWORD_DEFAULT), $u['id']]);
            }
            $pdo->prepare('UPDATE usuarios SET tentativas=0,bloqueado_ate=NULL,ultimo_login=NOW() WHERE id=?')->execute([$u['id']]);
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$u['id'];
            $_SESSION['ultima_atividade'] = time();
            unset($_SESSION['csrf']);
            redirecionar('index.php');
        } else {
            if ($u) {
                $t = (int)$u['tentativas'] + 1;
                if ($t >= LOGIN_MAX_TENTATIVAS) {
                    $pdo->prepare('UPDATE usuarios SET tentativas=0,bloqueado_ate=DATE_ADD(NOW(),INTERVAL ? MINUTE) WHERE id=?')->execute([LOGIN_BLOQUEIO_MIN, $u['id']]);
                } else {
                    $pdo->prepare('UPDATE usuarios SET tentativas=? WHERE id=?')->execute([$t, $u['id']]);
                }
            }
            $erro = $generico;
        }
    } catch (Throwable $ex) {
        error_log('Erro no login: '.$ex->getMessage());
        $erro = 'Não foi possível entrar agora. Tente novamente.';
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Entrar | Bistrô Sabor da Vila</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page">
<main class="login-box"><div class="panel">
<a class="brand login-brand" href="login.php"><span class="brand-icon">SV</span><span>Bistrô <b>Sabor da Vila</b><small>PAINEL DE COMANDAS</small></span></a>
<h1 class="login-title">Entrar</h1><p class="hint">Acesso restrito à equipe do bistrô.</p>
<?php if($erro):?><div class="alert error"><?=e($erro)?></div><?php endif;?>
<form method="post" class="admin-form" autocomplete="on"><?=csrf_campo()?>
<label>Usuário<input name="usuario" required maxlength="60" autocomplete="username" autofocus value="<?=e($_POST['usuario'] ?? '')?>"></label>
<label>Senha<input name="senha" type="password" required maxlength="72" autocomplete="current-password"></label>
<button class="button primary full" type="submit">Entrar</button></form>
<p class="hint login-link">Ainda não tem conta? <a href="cadastro.php">Criar conta</a></p>
</div></main></body></html>
