<?php
declare(strict_types=1);
// Configuração para InfinityFree. Só falta trocar a senha na linha $dbPass.
$dbHost = 'sql111.infinityfree.com';
$dbName = 'if0_43477211_bistro';
$dbUser = 'if0_43477211';
$dbPass = 'COLOQUE_AQUI_A_SENHA_DO_PAINEL';
try {
    $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '-03:00'");
} catch (PDOException $e) {
    error_log('Erro de conexão: '.$e->getMessage());
    http_response_code(500);
    exit('Não foi possível conectar ao banco. Confira a senha em config/database.php e importe database_infinityfree.sql.');
}
