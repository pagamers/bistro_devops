-- Para bancos que JÁ rodaram a versão anterior do login (perfis principal/admin/atendente).
-- Rode UMA vez, no banco selecionado. Não apaga comandas, produtos nem contas.
-- Conversão: principal -> admin | atendente -> funcionario | cadastros pendentes -> cliente ativo.
ALTER TABLE usuarios MODIFY perfil ENUM('principal','admin','atendente','cliente','funcionario') NOT NULL DEFAULT 'cliente';
UPDATE usuarios SET perfil='admin' WHERE perfil='principal';
UPDATE usuarios SET perfil='funcionario' WHERE perfil='atendente' AND pendente=0;
UPDATE usuarios SET perfil='cliente', ativo=1, pendente=0 WHERE pendente=1;
ALTER TABLE usuarios MODIFY perfil ENUM('cliente','funcionario','admin') NOT NULL DEFAULT 'cliente';
ALTER TABLE usuarios DROP COLUMN pendente;
ALTER TABLE comandas ADD COLUMN usuario_id INT UNSIGNED DEFAULT NULL AFTER numero;
ALTER TABLE comandas ADD INDEX idx_comandas_usuario (usuario_id);
ALTER TABLE comandas ADD CONSTRAINT fk_comandas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
