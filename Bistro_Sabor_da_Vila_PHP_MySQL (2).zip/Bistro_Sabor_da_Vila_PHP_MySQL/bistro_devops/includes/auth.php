<?php
declare(strict_types=1);
// Autenticação, autorização (perfis), sessão e proteção CSRF.
// Hierarquia de contas (cada nível faz tudo que o anterior faz):
//   cliente     (1): só faz pedidos (e vê os próprios).
//   funcionario (2): faz pedidos + modifica os processos (entregar, observações, cardápio).
//   admin       (3): tudo isso + painel de contas (cria e atualiza contas de funcionário e admin).

const SESSAO_OCIOSA_MAX = 7200;   // 2 h sem atividade encerra a sessão
const LOGIN_MAX_TENTATIVAS = 5;   // falhas seguidas antes de bloquear a conta
const LOGIN_BLOQUEIO_MIN = 10;    // minutos de bloqueio

function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function brl($v): string { return 'R$ '.number_format((float)$v, 2, ',', '.'); }

function rank_perfil(string $p): int { return ['cliente' => 1, 'funcionario' => 2, 'admin' => 3][$p] ?? 0; }
function rotulo_perfil(string $p): string { return ['cliente' => 'Cliente', 'funcionario' => 'Funcionário', 'admin' => 'Admin'][$p] ?? $p; }
function eh_funcionario(array $u): bool { return rank_perfil((string)$u['perfil']) >= 2; }   // funcionário ou admin

function sessao_iniciar(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'secure' => $https,
        'httponly' => true, 'samesite' => 'Lax',
    ]);
    session_name('bistro_sessao');
    session_start();
}

function redirecionar(string $destino): void {
    header('Location: '.$destino);
    exit;
}

function csrf_token(): string {
    sessao_iniciar();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_campo(): string {
    return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">';
}
function csrf_validar(): void {
    sessao_iniciar();
    $enviado = (string)($_POST['csrf'] ?? '');
    if ($enviado === '' || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $enviado)) {
        http_response_code(403);
        exit('Requisição inválida ou sessão expirada. Volte, recarregue a página e tente novamente.');
    }
}

/** Retorna o usuário logado (relido do banco a cada requisição) ou null. */
function usuario_atual(PDO $pdo): ?array {
    sessao_iniciar();
    $id = (int)($_SESSION['uid'] ?? 0);
    if (!$id) return null;
    if (time() - (int)($_SESSION['ultima_atividade'] ?? 0) > SESSAO_OCIOSA_MAX) { sessao_encerrar(); return null; }
    $s = $pdo->prepare('SELECT id,nome,usuario,perfil,trocar_senha FROM usuarios WHERE id=? AND ativo=1');
    $s->execute([$id]);
    $u = $s->fetch();
    if (!$u) { sessao_encerrar(); return null; }
    $_SESSION['ultima_atividade'] = time();
    return $u;
}

function sessao_encerrar(): void {
    sessao_iniciar();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', ['expires' => time() - 3600, 'path' => $p['path'],
            'secure' => $p['secure'], 'httponly' => true, 'samesite' => 'Lax']);
    }
    session_destroy();
}

/** Exige login; obriga a troca de senha provisória antes de qualquer outra página. */
function exigir_login(PDO $pdo): array {
    $u = usuario_atual($pdo);
    if (!$u) redirecionar('login.php');
    $atual = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ((int)$u['trocar_senha'] === 1 && $atual !== 'senha.php') redirecionar('senha.php');
    return $u;
}

function exigir_perfil(array $u, string ...$perfis): void {
    if (!in_array($u['perfil'], $perfis, true)) {
        http_response_code(403);
        exit('Acesso negado: seu perfil não tem permissão para esta página. <a href="index.php">Voltar</a>');
    }
}

function topbar(array $u, string $ativa): void {
    $item = fn(string $chave, string $href, string $rotulo) =>
        '<a'.($ativa === $chave ? ' class="nav-active"' : '').' href="'.$href.'">'.$rotulo.'</a>';
    echo '<header class="topbar"><div class="wrap topbar-inner"><a class="brand" href="index.php"><span class="brand-icon">SV</span><span>Bistrô <b>Sabor da Vila</b><small>PAINEL DE COMANDAS</small></span></a><nav>';
    if ((int)$u['trocar_senha'] !== 1) {
        echo $item('comandas', 'index.php', eh_funcionario($u) ? 'Comandas' : 'Meus pedidos');
        if (eh_funcionario($u)) echo $item('produtos', 'produtos.php', 'Produtos');
        if ($u['perfil'] === 'admin') echo $item('usuarios', 'usuarios.php', 'Painel de contas');
    }
    echo $item('senha', 'senha.php', 'Minha senha');
    echo '<form method="post" action="logout.php" class="logout-form">'.csrf_campo().'<button type="submit" class="nav-button">Sair ('.e($u['usuario']).')</button></form>';
    echo '</nav></div></header>';
}

/** Regras mínimas de senha. Retorna mensagem de erro ou null se válida. */
function validar_senha_nova(string $senha): ?string {
    if (strlen($senha) < 8) return 'A senha deve ter pelo menos 8 caracteres.';
    if (strlen($senha) > 72) return 'A senha deve ter no máximo 72 caracteres.';
    if (!preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) return 'Use letras e números na senha.';
    return null;
}
