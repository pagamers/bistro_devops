<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
$usuario = exigir_login($pdo);
$forcada = (int)$usuario['trocar_senha'] === 1;
$erro = ''; $sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $atual = (string)($_POST['senha_atual'] ?? '');
    $nova = (string)($_POST['senha_nova'] ?? '');
    $conf = (string)($_POST['senha_conf'] ?? '');
    try {
        $s = $pdo->prepare('SELECT senha_hash FROM usuarios WHERE id=?');
        $s->execute([$usuario['id']]);
        $hash = (string)$s->fetchColumn();
        if (!password_verify($atual, $hash)) $erro = 'A senha atual está incorreta.';
        elseif ($nova !== $conf) $erro = 'A confirmação não confere com a nova senha.';
        elseif ($nova === $atual) $erro = 'A nova senha deve ser diferente da atual.';
        elseif (($msg = validar_senha_nova($nova)) !== null) $erro = $msg;
        else {
            $pdo->prepare('UPDATE usuarios SET senha_hash=?,trocar_senha=0 WHERE id=?')->execute([password_hash($nova, PASSWORD_DEFAULT), $usuario['id']]);
            session_regenerate_id(true);
            $usuario['trocar_senha'] = 0; $forcada = false;
            $sucesso = 'Senha alterada com sucesso.';
        }
    } catch (Throwable $ex) {
        error_log('Erro ao trocar senha: '.$ex->getMessage());
        $erro = 'Não foi possível alterar a senha.';
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Minha senha | Bistrô Sabor da Vila</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php topbar($usuario, 'senha'); ?>
<main class="wrap"><section class="hero"><div><span class="eyebrow">CONTA</span><h1>Minha senha</h1><p><?=$forcada?'Sua senha é provisória. Defina uma nova para continuar.':'Troque sua senha de acesso.'?></p></div><div class="hero-mark">🔑</div></section>
<?php if($erro):?><div class="alert error"><?=e($erro)?></div><?php endif;?><?php if($sucesso):?><div class="alert success"><?=e($sucesso)?> <a href="index.php">Ir para as comandas</a></div><?php endif;?>
<div class="panel narrow"><form method="post" class="admin-form"><?=csrf_campo()?>
<label>Senha atual<input name="senha_atual" type="password" required maxlength="72" autocomplete="current-password"></label>
<label>Nova senha <span class="muted">(mín. 8 caracteres, com letras e números)</span><input name="senha_nova" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></label>
<label>Confirmar nova senha<input name="senha_conf" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></label>
<button class="button primary full" type="submit">Salvar nova senha</button></form></div>
<footer>Projeto didático • UC2 — Práticas DevOps em Projetos Web <span>PHP + MySQL</span></footer></main></body></html>
