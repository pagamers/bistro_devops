<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
$usuario = exigir_login($pdo);
exigir_perfil($usuario, 'admin');          // painel exclusivo de contas admin
const PERFIS = ['cliente', 'funcionario', 'admin'];
$erro = ''; $sucesso = ''; $editandoId = null;

function carregar_conta(PDO $pdo, $idRaw): ?array {
    $id = filter_var($idRaw, FILTER_VALIDATE_INT);
    if (!$id) return null;
    $s = $pdo->prepare('SELECT id,nome,usuario,perfil,ativo,trocar_senha FROM usuarios WHERE id=?');
    $s->execute([$id]);
    return $s->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = (string)($_POST['acao'] ?? '');
    try {
        if ($acao === 'criar') {
            $nome = trim((string)($_POST['nome'] ?? ''));
            $login = strtolower(trim((string)($_POST['usuario'] ?? '')));
            $senha = (string)($_POST['senha'] ?? '');
            $perfil = (string)($_POST['perfil'] ?? '');
            $trocar = isset($_POST['trocar_senha']) ? 1 : 0;
            if ($nome === '' || mb_strlen($nome) > 120) $erro = 'Informe o nome (até 120 caracteres).';
            elseif (!preg_match('/^[a-z0-9._-]{3,60}$/', $login)) $erro = 'Usuário: 3 a 60 caracteres, só minúsculas, números, ponto, hífen e sublinhado.';
            elseif (!in_array($perfil, ['funcionario', 'admin'], true)) $erro = 'Escolha Funcionário ou Admin.';
            elseif (($msg = validar_senha_nova($senha)) !== null) $erro = $msg;
            else {
                $existe = $pdo->prepare('SELECT 1 FROM usuarios WHERE usuario=?'); $existe->execute([$login]);
                if ($existe->fetch()) $erro = 'Esse nome de usuário já existe.';
                else {
                    $pdo->prepare('INSERT INTO usuarios (nome,usuario,senha_hash,perfil,trocar_senha,criado_por) VALUES (?,?,?,?,?,?)')
                        ->execute([$nome, $login, password_hash($senha, PASSWORD_DEFAULT), $perfil, $trocar, $usuario['id']]);
                    $sucesso = 'Conta "'.$login.'" ('.rotulo_perfil($perfil).') criada.';
                }
            }
        } elseif ($acao === 'salvar') {
            $alvo = carregar_conta($pdo, $_POST['id'] ?? '');
            if (!$alvo) $erro = 'Conta não encontrada.';
            else {
                $editandoId = (int)$alvo['id'];
                $proprio = $editandoId === (int)$usuario['id'];   // admin não rebaixa nem desativa a si mesmo
                $nome = trim((string)($_POST['nome'] ?? ''));
                $login = trim((string)($_POST['usuario'] ?? ''));
                if ($login !== $alvo['usuario']) $login = strtolower($login);
                $perfil = $proprio ? $alvo['perfil'] : (string)($_POST['perfil'] ?? '');
                $ativo = $proprio ? 1 : (isset($_POST['ativo']) ? 1 : 0);
                $nova = (string)($_POST['senha_nova'] ?? '');
                $trocar = isset($_POST['trocar_senha']) ? 1 : 0;
                if ($nome === '' || mb_strlen($nome) > 120) $erro = 'Informe o nome (até 120 caracteres).';
                elseif ($login !== $alvo['usuario'] && !preg_match('/^[a-z0-9._-]{3,60}$/', $login)) $erro = 'Usuário: 3 a 60 caracteres, só minúsculas, números, ponto, hífen e sublinhado.';
                elseif (!in_array($perfil, PERFIS, true)) $erro = 'Perfil inválido.';
                elseif ($nova !== '' && ($msg = validar_senha_nova($nova)) !== null) $erro = $msg;
                else {
                    $dup = $pdo->prepare('SELECT 1 FROM usuarios WHERE usuario=? AND id<>?'); $dup->execute([$login, $alvo['id']]);
                    if ($dup->fetch()) $erro = 'Esse nome de usuário já existe.';
                    elseif ($nova !== '') {
                        $pdo->prepare('UPDATE usuarios SET nome=?,usuario=?,perfil=?,ativo=?,senha_hash=?,trocar_senha=?,tentativas=0,bloqueado_ate=NULL WHERE id=?')
                            ->execute([$nome, $login, $perfil, $ativo, password_hash($nova, PASSWORD_DEFAULT), $trocar, $alvo['id']]);
                        $sucesso = 'Conta atualizada e senha redefinida.';
                    } else {
                        $pdo->prepare('UPDATE usuarios SET nome=?,usuario=?,perfil=?,ativo=?,tentativas=0,bloqueado_ate=NULL WHERE id=?')
                            ->execute([$nome, $login, $perfil, $ativo, $alvo['id']]);
                        $sucesso = 'Conta atualizada.';
                    }
                }
            }
        } elseif ($acao === 'alternar') {
            $alvo = carregar_conta($pdo, $_POST['id'] ?? '');
            if (!$alvo) $erro = 'Conta não encontrada.';
            elseif ((int)$alvo['id'] === (int)$usuario['id']) $erro = 'Você não pode desativar a sua própria conta.';
            else {
                $pdo->prepare('UPDATE usuarios SET ativo=IF(ativo=1,0,1),tentativas=0,bloqueado_ate=NULL WHERE id=?')->execute([$alvo['id']]);
                $sucesso = 'Situação da conta atualizada.';
            }
        } else $erro = 'Ação inválida.';
    } catch (Throwable $ex) {
        error_log('Erro painel de contas: '.$ex->getMessage());
        $erro = 'Não foi possível concluir a operação.'; $sucesso = '';
    }
}

$editando = null;
$idEdit = $editandoId ?? (filter_var($_GET['editar'] ?? '', FILTER_VALIDATE_INT) ?: null);
if ($idEdit) $editando = carregar_conta($pdo, $idEdit);
$proprioEdit = $editando && (int)$editando['id'] === (int)$usuario['id'];

$ver = in_array($_GET['ver'] ?? '', PERFIS, true) ? (string)$_GET['ver'] : '';
$sql = 'SELECT u.id,u.nome,u.usuario,u.perfil,u.ativo,u.ultimo_login,c.nome AS criador FROM usuarios u LEFT JOIN usuarios c ON c.id=u.criado_por';
$sql .= $ver !== '' ? ' WHERE u.perfil=?' : '';
$sql .= " ORDER BY FIELD(u.perfil,'admin','funcionario','cliente'),u.ativo DESC,u.nome";
$s = $pdo->prepare($sql); $s->execute($ver !== '' ? [$ver] : []);
$lista = $s->fetchAll();
$totais = array_column($pdo->query('SELECT perfil,COUNT(*) n FROM usuarios GROUP BY perfil')->fetchAll(), 'n', 'perfil');
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Painel de contas | Bistrô Sabor da Vila</title><link rel="stylesheet" href="assets/style.css"></head><body>
<?php topbar($usuario, 'usuarios'); ?>
<main class="wrap"><section class="hero"><div><span class="eyebrow">EXCLUSIVO DE ADMINISTRADORES</span><h1>Painel de contas</h1><p>Crie e atualize contas de funcionário e admin, quando quiser. Clientes se cadastram sozinhos.</p></div><div class="hero-mark">👥</div></section>
<?php if($erro):?><div class="alert error"><?=e($erro)?></div><?php endif;?>
<?php if($sucesso):?><div class="alert success"><?=e($sucesso)?></div><?php endif;?>
<section class="product-admin-grid">
<?php if($editando):?>
<div class="panel"><div class="panel-heading"><div><span class="step">ATUALIZAR CONTA</span><h2><?=e($editando['nome'])?></h2></div></div>
<form method="post" class="admin-form" autocomplete="off"><?=csrf_campo()?><input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?=(int)$editando['id']?>">
<label>Nome<input name="nome" required maxlength="120" value="<?=e($editando['nome'])?>"></label>
<label>Usuário (login)<input name="usuario" required maxlength="60" value="<?=e($editando['usuario'])?>"></label>
<label>Perfil<select name="perfil" <?=$proprioEdit?'disabled':''?>><?php foreach(PERFIS as $p):?><option value="<?=e($p)?>" <?=$p===$editando['perfil']?'selected':''?>><?=e(rotulo_perfil($p))?></option><?php endforeach;?></select></label>
<label class="check-line"><input type="checkbox" name="ativo" value="1" <?=(int)$editando['ativo']===1?'checked':''?> <?=$proprioEdit?'disabled':''?>> Conta ativa (pode entrar no sistema)</label>
<?php if($proprioEdit):?><p class="hint">Em sua própria conta você não pode alterar o perfil nem desativar.</p><?php endif;?>
<label>Nova senha <span class="muted">(deixe em branco para manter)</span><input name="senha_nova" type="password" maxlength="72" autocomplete="new-password"></label>
<label class="check-line"><input type="checkbox" name="trocar_senha" value="1" <?=(int)$editando['trocar_senha']===1?'checked':''?>> Exigir troca de senha no próximo acesso</label>
<button class="button primary full" type="submit">Salvar alterações</button><a class="cancel-link" href="usuarios.php<?=$ver!==''?'?ver='.e($ver):''?>">Cancelar edição</a></form></div>
<?php else:?>
<div class="panel"><div class="panel-heading"><div><span class="step">NOVA CONTA</span><h2>Criar funcionário ou admin</h2></div></div>
<form method="post" class="admin-form" autocomplete="off"><?=csrf_campo()?><input type="hidden" name="acao" value="criar">
<label>Nome<input name="nome" required maxlength="120" placeholder="Ex.: Maria Souza"></label>
<label>Usuário (login)<input name="usuario" required maxlength="60" pattern="[a-z0-9._\-]{3,60}" placeholder="ex.: maria.souza" autocapitalize="none"></label>
<label>Tipo de conta<select name="perfil"><option value="funcionario">Funcionário</option><option value="admin">Admin</option></select></label>
<label>Senha inicial <span class="muted">(mín. 8, com letras e números)</span><input name="senha" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></label>
<label class="check-line"><input type="checkbox" name="trocar_senha" value="1" checked> Exigir troca de senha no primeiro acesso</label>
<button class="button primary full" type="submit">Criar conta</button></form></div>
<?php endif;?>
<div class="panel inventory"><div class="section-heading"><div><span class="step">TODAS AS CONTAS</span><h2>Contas cadastradas</h2></div><span class="count"><?=array_sum($totais)?> contas</span></div>
<div class="filter-tabs"><a class="<?=$ver===''?'on':''?>" href="usuarios.php">Todas</a><a class="<?=$ver==='admin'?'on':''?>" href="usuarios.php?ver=admin">Admins (<?=(int)($totais['admin']??0)?>)</a><a class="<?=$ver==='funcionario'?'on':''?>" href="usuarios.php?ver=funcionario">Funcionários (<?=(int)($totais['funcionario']??0)?>)</a><a class="<?=$ver==='cliente'?'on':''?>" href="usuarios.php?ver=cliente">Clientes (<?=(int)($totais['cliente']??0)?>)</a></div>
<?php if(!$lista):?><div class="empty">Nenhuma conta neste filtro.</div><?php else:?><div class="table-wrap"><table><thead><tr><th>Conta</th><th>Perfil</th><th>Criada por</th><th>Último acesso</th><th>Status</th><th>Ações</th></tr></thead><tbody>
<?php foreach($lista as $x): $eu=(int)$x['id']===(int)$usuario['id'];?><tr><td><strong><?=e($x['nome'])?><?=$eu?' (você)':''?></strong><small class="desc-cell"><?=e($x['usuario'])?></small></td><td><?=e(rotulo_perfil($x['perfil']))?></td><td><?=e($x['criador'] ?? ($x['perfil']==='cliente'?'Autocadastro':'—'))?></td><td><?=$x['ultimo_login']?e(date('d/m/Y H:i',strtotime($x['ultimo_login']))):'—'?></td><td><span class="status <?=$x['ativo']?'status-done':'status-off'?>"><?=$x['ativo']?'Ativo':'Inativo'?></span></td>
<td><div class="table-actions"><a class="small-link" href="usuarios.php?editar=<?=(int)$x['id']?><?=$ver!==''?'&amp;ver='.e($ver):''?>">Editar</a>
<?php if(!$eu):?><form method="post" onsubmit="return confirm('Alterar o acesso desta conta?')"><?=csrf_campo()?><input type="hidden" name="acao" value="alternar"><input type="hidden" name="id" value="<?=(int)$x['id']?>"><button class="text-button" type="submit"><?=$x['ativo']?'Desativar':'Ativar'?></button></form><?php endif;?></div></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></div></section>
<footer>Projeto didático • UC2 — Práticas DevOps em Projetos Web <span>PHP + MySQL</span></footer></main></body></html>
